# Project 3

## clarinet-chicken

Jacob Cain (jrc632)

Matthew Flanders (mtf83)

Teng Ao (od79)

## Instruction
Move with WASD
Jump with SPACE
Interact with E
When a music challenge begins use the top row qwerty keys, tab, and space to play the notes. The keys to be played are:
TAB Q W E R U I O P SPACE

Interact with the sign once you have completed 3 challenges to leave the level and win the game. 


 
#	Known	Bugs	or	Issues

No known bugs.


## Credits

Jacob Cain: 
sprites for chicken man, clarinet, ranger npc. 
Code for music battle, player movement, menu. 

Matthew Flanders: 
Level layout, sprites for level objects.
Title screen tween. 
Sequences and sprites for objective markers. 

Teng Ao: Creates Enemies Sprites, animation and endroom, 
readme file.
 
 

# Project 2

## Cave-Escape

Jacob Cain (jrc632)

Matthew Flanders (mtf83)

Teng Ao (od79)

## Instruction

The cave-Escape game is about we control a character (gnome) and collect the staffs like axe, 
mushrooms then heal the NPC and use Axe to break the rocks to explore other caves. Finally
we will escape the Cave.

How the game works:

Use Up, Down, Left, Right on keyboard to control the gnome, press Space to use the staff in the 
cave.

 
#	Known	Bugs	or	Issues

No known bugs.


## Credits

Jacob Cain: Creates Blue/Red Gnome, tiles, Collisons, Objects, inventories, musics, lava room, doors
bounding box, woodpile, sequence.

Matthew Flanders: Creates rooms,sprites,movements, pickaxe, torch, objects, dialogue, title tweening.

Teng Ao: Creates Gnome, torch animations, Title/End Rooms, tiles, sprites, Readme file.

  
 
 
